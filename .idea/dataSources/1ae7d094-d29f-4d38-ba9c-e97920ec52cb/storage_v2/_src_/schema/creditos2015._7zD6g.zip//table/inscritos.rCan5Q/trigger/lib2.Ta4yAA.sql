create definer = root@`%` trigger lib2
    after update
    on inscritos
    for each row
begin
    Set @part=(select no_partes from sub_actividades where id_subactividad=new.id_subactividad);
    Set @acti=(select id_actividad from sub_actividades where id_subactividad=new.id_subactividad);
    Set @evi=(select no_evidencias from sub_actividades where id_subactividad=new.id_subactividad);
    if(new.total_evidencias=@evi) then
    insert into liberados values(null,new.no_control,@part,@acti);
    end if;
    end;

