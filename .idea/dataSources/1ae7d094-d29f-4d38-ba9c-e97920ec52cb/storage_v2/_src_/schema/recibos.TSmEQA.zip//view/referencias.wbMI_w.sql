create view referencias as
select `recibos`.`tabreferencias`.`refReferencia` AS `Referencia`,
       `recibos`.`tabreferencias`.`refFecha`      AS `Fecha`,
       `recibos`.`tabreferencias`.`refImporte`    AS `Importe`,
       `recibos`.`tabreferencias`.`recFolio`      AS `Recibo`,
       `recibos`.`tabrecibos`.`recFecha`          AS `recFecha`,
       `recibos`.`tabrecibos`.`recTotal`          AS `recTotal`,
       `recibos`.`tabrecibos`.`aluControl`        AS `aluControl`
from (`recibos`.`tabrecibos`
         join `recibos`.`tabreferencias`
              on (`recibos`.`tabrecibos`.`recFolio` = `recibos`.`tabreferencias`.`recFolio`));

