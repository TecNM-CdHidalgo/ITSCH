create view recibos as
select `recibos`.`tabrecibos`.`recFolio`                          AS `Folio`,
       `recibos`.`tabrecibos`.`recStatus`                         AS `Status`,
       date_format(`recibos`.`tabrecibos`.`recFecha`, '%d/%m/%Y') AS `Fecha`,
       `recibos`.`tabrecibos`.`aluControl`                        AS `NControl`,
       concat(`recibos`.`catalumnos`.`aluPaterno`, ' ', `recibos`.`catalumnos`.`aluMaterno`, ' ',
              `recibos`.`catalumnos`.`aluNombre`)                 AS `Nombre`,
       `recibos`.`tabrecibos`.`recTotal`                          AS `Cantidad`,
       `recibos`.`tabrecibos`.`recObs`                            AS `Observaciones`
from (`recibos`.`tabrecibos`
         left join `recibos`.`catalumnos`
                   on (`recibos`.`tabrecibos`.`aluControl` = `recibos`.`catalumnos`.`aluControl`));

