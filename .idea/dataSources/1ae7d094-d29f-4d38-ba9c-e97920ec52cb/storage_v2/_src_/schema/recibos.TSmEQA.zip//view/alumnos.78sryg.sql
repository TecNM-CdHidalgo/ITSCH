create view alumnos as
select `recibos`.`catalumnos`.`aluControl`        AS `aluControl`,
       concat(`recibos`.`catalumnos`.`aluPaterno`, ' ', `recibos`.`catalumnos`.`aluMaterno`, ' ',
              `recibos`.`catalumnos`.`aluNombre`) AS `nombre`
from `recibos`.`catalumnos`;

